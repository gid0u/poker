# 全52C7ハンド評価辞書

全133,784,560通りの7枚集合を収録。並び順は不問。
最強=1、順位は既存の7462役クラス基準。同じ強さは同じ順位。
7枚のベスト5枚で現れる順位は4824種類。勝率ではありません。

ZIPを展開して、そのフォルダで次を実行してください（Python 3.13+、外部依存なし）。

    python query.py As Ks Qs Js Ts 2c 3d

結果は rank=1, value=[8,14], category=straight_flush です。

Pythonプログラムから:

    from poker_evaluator.seven_card_dictionary import SevenCardRankDictionary
    with SevenCardRankDictionary("展開したフォルダ", verify_checksum=True) as table:
        rank = table["As Ks Qs Js Ts 2c 3d"]

seven_card_ranks.u16: 267,569,120 bytes、little-endian uint16
seven_card_ranks.json: 形式と7462役クラス定義、SHA-256
verification.json: 全件走査と10,002件の既存評価器との照合結果
query.py / poker_evaluator/: 標準ライブラリだけで動く検索用コード

raw key: card_id=4*(rank-2)+suit、suitはs,c,h,dの順で0,1,2,3。
index=sum(C(sorted_id[i],i+1) for i in range(7))。
index位置の2バイトが順位です。全件をPythonのdictへ展開する必要はありません。

全件集計は検証済みですが、別評価器による二重照合は抽出10,002件です。
カード認識や相手レンジ推定はこの辞書には含みません。
