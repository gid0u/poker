from pathlib import Path
import json
import sys
from poker_evaluator.seven_card_dictionary import SevenCardRankDictionary, hand_index

cards = sys.argv[1:] or "As Ks Qs Js Ts 2c 3d".split()
if len(cards) == 1:
    cards = cards[0].split()
with SevenCardRankDictionary(Path(__file__).resolve().parent) as table:
    if any(c.upper().startswith("X") or c[-1].upper() in "OPQR" for c in cards):
        from dataclasses import asdict
        print(json.dumps(asdict(table.evaluate_wildcards(" ".join(cards))), indent=2))
    else:
        print(json.dumps(dict(cards=cards, index=hand_index(cards), rank=table[cards],
                             value=table.value(cards), category=table.category(cards)), indent=2))
